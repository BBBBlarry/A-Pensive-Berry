function [centroids, idx, L] = getImageCluster(path, letters, kMeanItr, doesShowText)
%% Initialization
close all; clc
more off

%% =================== K-Means Clustering ======================
%  After you have completed the two functions computeCentroids and
%  findClosestCentroids, you have all the necessary pieces to run the
%  kMeans algorithm. In this part, you will run the K-Means algorithm on
%  the example dataset we have provided. 
%

fprintf('\nPreparing Data.\n\n');

%thresold = 60000; % differentaite txt from bg
threshold = 200; % for some reason some pictures are weird
[gray, X, txt_idx, bg_idx] = processImage(path, threshold); %get gray scale img, coordinates of txt

%uncomment to test X selection
%gray((i + (j - 1) * m))= 0  %intensify X selection

gray(txt_idx) = 0; %intensify the text
gray(bg_idx) = 255; %lessen the intensity of the bg

[m,n] = size(gray);

%% uncomment to disp image
if doesShowText
  imshow(gray);
  pause;
end



fprintf('\nRunning K-Means clustering on example dataset.\n\n');

% Run  K-Means algorithm 
K = letters; %number of centroids or characters
max_iters = kMeanItr;

% When using K-Means, it is important the initialize the centroids
% randomly.
initial_centroids = kMeansInitCentroids(X, K);

% Run K-Means
[centroids, idx] = runkMeans(X, initial_centroids, max_iters);

fprintf('kMean finished. Press enter to continue.\n');
pause;

centroids = round(centroids) %get pixel location 

for a = 1:K
    q = idx == a; %idx of ith cluster index
    v = X .* q; %pixel location of ith cluster index
    %disp(v);
    vidx = find(v(:,1)); % find rows that contains non-zero values
    v = v(vidx, :); % only contain coordinates of ith index cluster pixels
    %%disp(B(p .* m + v))
    
    %dynamic intensity
    %MAX_INTENSITY = 50000;
    MAX_INTENSITY = 100;
    gray(v(:,1)  + (v(:,2) - 1) .* m) = (MAX_INTENSITY / K) * a;
    
% hard code intensity
%    if a == 1
%      gray(v(:,1)  + (v(:,2) - 1) .* m) = 0
%    elseif a == 2
%      gray(v(:,1)  + (v(:,2) - 1) .* m) = 30000
%    else
%      gray(v(:,1)  + (v(:,2) - 1) .* m) = 50000
%    end
end

imshow(gray);

end