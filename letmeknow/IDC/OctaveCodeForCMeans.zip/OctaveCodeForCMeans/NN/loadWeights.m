%% Neural Network 

function [Theta1, Theta2] = loadWeights()

% Loading Parameters
fprintf('\nLoading Saved Neural Network Parameters ...\n')
% Load the weights into variables Theta1 and Theta2
load('trainedWeights.mat');

end