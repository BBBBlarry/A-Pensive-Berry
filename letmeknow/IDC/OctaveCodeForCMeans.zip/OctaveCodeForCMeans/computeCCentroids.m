function centroids = computeCCentroids(X, idx, K, L)

% Useful variables
[m n] = size(X);
centroids = zeros(K, n);

for i = 1:K
  xi = X(find(idx==i),:);
  
  %geo centroids
  %centroids(i,:) =  sum(xi,1) .* (1/size(xi,1));
  
  max_p = max(xi);
  min_p = min(xi);
  
  % rcc = ( c - min ) / ( max - min);
  % cc = rcc * (max_new- min_new) + min_new;
  rcc = getRCC(L(i));
  cc = rcc * (max_p - min_p) + min_p;
  
  centroids(i,:)  = cc;
  
endfor


end