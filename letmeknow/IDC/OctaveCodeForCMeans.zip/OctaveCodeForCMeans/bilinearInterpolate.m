function [gray] = bilinearInterpolate(zz, m, n)
  x_scale = m/size(zz, 2);
  y_scale = n/size(zz,1);
  
  %[xx, yy] = meshgrid([-2:.1:2]);
  %zz = 1./(xx.^2+yy.^2+1);
  
  [xxi, yyi] = meshgrid(1:(1/x_scale): size(zz, 2), 1:(1/y_scale):size(zz,1));
  new_zz = interp2(zz, xxi, yyi, 'nearest');
  gray = new_zz;
  % imshow(new_zz);
end