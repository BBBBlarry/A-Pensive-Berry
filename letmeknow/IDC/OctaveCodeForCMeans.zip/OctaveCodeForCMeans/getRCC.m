function rcc = getRCC(character)
  % map character -> 1 -9, 0, a-z
  % relative character centriods
  
  RCC = [
    0.48485, 0.5; % 1
    0.52381, 0.41379; % 2
    0.48485, 0.52000; % 3
    0.48571, 0.55263; % 4
    0.42424, 0.47826; % 5
    0.57778, 0.40000; % 6
    0.42105, 0.73913; % 7
    0.47273, 0.60000; % 8
    0.44681, 0.50000; % 9
    0.48148, 0.56250; % 0
  ];
  
  rcc = RCC(character);
  
end