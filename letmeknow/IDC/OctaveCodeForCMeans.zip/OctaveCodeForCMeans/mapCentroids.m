function centroids = mapCentroids(centroids)
K = size(centroids, 1);

dim = 1;

[U, S] = pca(centroids);
Z = projectData(centroids, U, dim);
centroids_rec  = recoverData(Z, U, dim);

% map centroids' onto a line using PCA
%mappedCentroids = centroids_rec;

%netrualize? 
%mappedCentroids = (mappedCentroids + centroids_rec) ./ 2; %average
mappedCentroids = (centroids_rec - centroids)/2 + centroids; %average

centroids = mappedCentroids;
end