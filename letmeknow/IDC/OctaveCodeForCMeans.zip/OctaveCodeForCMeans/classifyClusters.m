function  [letters, confidence] = classifyClusters(X, K, idx)

% load NN library
addpath ("./NN");

%   CLASSIFYCLUSTERS This function predicts a character 
%   for each cluster that it most likely to represent

% convert X, idx to C, where C has (k, x, y)
C = cell(K, 1);
for i= 1:size(X, 1)
  k = idx(i);
  C(k) = [C{k};X(i, :)];
end

% for each k, convert x, y domain to coordinate domain
I = cell(K, 1);
for c_idx = 1:K
  % select values
  c = C{c_idx};
  
  % find max and min x and y coordinates
  x_min = min(c(:, 1));
  y_min = min(c(:, 2));
  
  cluster_x_range = range(c(:, 1));
  cluster_y_range = range(c(:, 2));
  
  
  
  % the size of the character relative to the entire image
  character_relative_size = 0.70;
  
  % NN is going to classify a 28*28 image
  % so the cluster is going to be a square
  if cluster_x_range > cluster_y_range
    cluster_size_length = round((cluster_x_range  + 1) / character_relative_size); % give some edges to the image
  else 
    cluster_size_length = round((cluster_y_range  + 1) / character_relative_size); % give some edges to the image
  end
  
  % create black background of the image (nerual network is trained this way...)
  i = zeros(cluster_size_length) ;
  
  
  
  %%%%%%%%%%%%%%%%%%%%%%% good stuff %%%%%%%%%%%%%%%%%%%%%
  
  % move image to the left 
  c(:, 1) = c(:, 1) - x_min + 1;
  c(:, 2) = c(:, 2) - y_min + 1;
  
  %%%%%%%% if the code below breaks, comment it and uncomment above code %%%%%%
  
  
  %%%%%%%%%%%%%%%%%% might break code %%%%%%%%%%%%%%%%%%%%
  % centering the image miht cause some of the data points to lay outside the border, 
  % so to solve the problem on a specific image, you can decrease character_relative_size
  % to interplolate the character smaller
  
  % finding the centriods of the cluster to centre it
  %c_x_centre = mean(c(:, 1)); 
  %c_y_centre = mean(c(:, 2)); 
  
  % centre the image
  %c_x_transfer = (cluster_size_length / 2) - c_x_centre; 
  %c_y_transfer = (cluster_size_length / 2) - c_y_centre;
  
  %c(:, 1) = round(c(:, 1) + c_x_transfer);
  %c(:, 2) = round(c(:, 2) + c_y_transfer);
  
  %%%%%%%%%%%%%%%%%% might break code %%%%%%%%%%%%%%%%%%%%
  
  
  
  % transfer c's R2 domain to R1 domain
  c_r1 = (c(:, 1) - 1).* (cluster_size_length) + c(:, 2);
  
  %assign white color to the cluster
  i(c_r1) = 255;
  
  % i think I did somthing reverse here............
  i = i';
  
  % append image to I
  I(c_idx) = i;
end


% scale matrices to 28 * 28
for c_idx = 1:K
  I(c_idx) = bilinearInterpolate(I{c_idx}, 28, 28);
   %debug
  imshow(I{c_idx});
end


% classify each cluser
L = zeros(K, 1);
%confidence of each prediction
Conf = zeros(K, 1);
% weights of the NN
[t1, t2] = loadWeights();

for c_idx = 1:K
  %data = featureNormalize(double(I{c_idx}));
  %[Conf(c_idx), L(c_idx)] = predict(t1, t2, data);
  %featureNormalize(I{c_idx})
  [Conf(c_idx), L(c_idx)] = predict(t1, t2, featureNormalize(I{c_idx}));
  
  imshow(I{c_idx});
  disp(strcat("Prediction: \0", num2str(L(c_idx))));
  disp(strcat("Confidence: \0", num2str(Conf(c_idx))));
  %pause;
  
end

letters = L;
confidence = Conf;

end