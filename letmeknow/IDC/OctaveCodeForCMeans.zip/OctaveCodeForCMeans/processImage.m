function [gray, X, txt_idx, bg_idx] = processImage(path, threshold)

f = imread(path);
info = imfinfo(path);

% Load an image of the word "you"
if isequal(info.ColorType, "1")
  disp("Is a grayscale image, no further processing needed...");
  gray = f;
else 
  disp("Not a grayscale image, further processing...");
  [x, map] = rgb2ind(f);
  gray = ind2gray(x, map);
end

  % convert them into 8-bit image if its 16-bit
if(strcmpi("uint16", class(gray)))
  gray = uint8(gray/256);
end

imshow(gray);

txt_idx = gray(:,:)<threshold; %thresold
bg_idx = gray(:,:)>=threshold; %get background idx

[i, j] = find(txt_idx);
X = [i,j]; % used for kMeans


end