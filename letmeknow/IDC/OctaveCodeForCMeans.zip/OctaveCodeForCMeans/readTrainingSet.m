function [X, y] = readTrainingSet(dsPath)

  fileNameTemplate = strcat(dsPath, "/data");
  X = zeros(10000, 28*28);
  y = zeros(10000, 1);
  
  count = 1
  
  for i = 0:9
    % get proper path
    figure = i;
    filePath = strcat(fileNameTemplate, num2str(figure))
    fid = fopen(filePath, "r");
    
    for j = 1:1000
 
      % get the image matrix
      temp = (fread(fid, [28, 28], "uint8"));
      
      % rotate the image 90 degrees
      %temp = temp';
      
      
      %%%%%%%%%%%%%%%%%%%%%%% good stuff %%%%%%%%%%%%%%%%%%%%%
      % NN is scale variant, convert the images to the left or top
      
      % convert map to coordinates
      
      txt_idx = temp(:,:) > 0; %thresold
      
      [i, j] = find(txt_idx);
      c = [i,j]; % coordinates
      
      % find max and min x and y coordinates
      x_min = min(c(:, 1));
      y_min = min(c(:, 2));
      
      cluster_size_length = 28;
      
      % create black background of the image (nerual network is trained this way...)
      img = zeros(cluster_size_length);

      % move image to the left 
      c(:, 1) = c(:, 1) - x_min + 1;
      c(:, 2) = c(:, 2) - y_min + 1;
      
      % convert coordinates to map
      c_r1 = (c(:, 1) - 1).* (cluster_size_length) + c(:, 2);
      
      %assign white color to the cluster
      img(c_r1) = 255;
      temp = img;
      
      
      %%%%%%%% if the code below breaks, comment it and uncomment above code %%%%%%
      
  
      
      
      % load into X as a row vector, y as a number
      X(count, :) = temp(:);
      y(count) = figure;
      
      count = count +1;
    end
    
    % close file
    fclose(fid);
  end
  
  % label 0's as 10
  y(1:1000) = 10;
  
  save trainingset.mat X
  save -append trainingset.mat y
  
end