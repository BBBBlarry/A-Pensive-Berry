function img = resizeImage(intensityMap, coordinates, dim)

m = dim(1); % number of rows
n = dim(2); % number of columns

left = min(coordinates(1,:));
right = max(coordinates(1,:));
top = min(coordinates(2,:));
bottom = max(coordinates(2,:));

img = intensityMap(top:bottom, left:right);



end