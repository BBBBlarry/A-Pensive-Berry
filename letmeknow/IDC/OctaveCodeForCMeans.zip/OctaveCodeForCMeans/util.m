function rcc = util(path)
  [centroid, idx] = getImageCluster(path, 1, 1, false);
  [gray, X, txt_idx, bg_idx] = processImage(path, 100); %get gray scale img, coordinates of txt
  min = min(X);
  max = max(X);
  rcc = (centroid - min) ./ (max - min);
end