//
//  Engine.cpp
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#include "Engine.h"

Engine::Engine(){
    dt = new DriveTrain();
    std::cout << "Engine made" << std::endl;
}

Engine::~Engine(){
    delete dt;
    std::cout << "Engine destroyed" << std::endl;
}

void Engine::Rev(int RPM){
    dt->Spinwheels(float(RPM));
}