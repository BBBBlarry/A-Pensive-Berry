//
//  Car.h
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#ifndef __C___PlayG__Car__
#define __C___PlayG__Car__

#include <iostream>
#include "Horn.h"
#include "Engine.h"

class Car{
public:
    
    Engine* eng;
    Horn* horn;
    
    Car();
    ~Car();
    void Drive(float fast);
    void Honk(std::string noise);
};

#endif /* defined(__C___PlayG__Car__) */
