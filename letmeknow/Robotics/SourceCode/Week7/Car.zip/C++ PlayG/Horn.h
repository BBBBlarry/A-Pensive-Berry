//
//  Horn.h
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#ifndef __C___PlayG__Horn__
#define __C___PlayG__Horn__

#include <iostream>
class Horn{
public:
    Horn();
    ~Horn();
    void Beep(std::string sound);
};

#endif /* defined(__C___PlayG__Horn__) */
