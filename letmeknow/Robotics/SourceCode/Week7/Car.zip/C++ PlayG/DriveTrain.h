//
//  DriveTrain.h
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#ifndef __C___PlayG__DriveTrain__
#define __C___PlayG__DriveTrain__

#include <iostream>
class DriveTrain{
public: 
    DriveTrain();
    ~DriveTrain();
    void Spinwheels(float KPH);
};

#endif /* defined(__C___PlayG__DriveTrain__) */
