//
//  Engine.h
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#ifndef __C___PlayG__Engine__
#define __C___PlayG__Engine__

#include <iostream>
#include "DriveTrain.h"

class Engine{
public:
    Engine();
    ~Engine();
    void Rev(int RPM);
    
    DriveTrain* dt;
};

#endif /* defined(__C___PlayG__Engine__) */
