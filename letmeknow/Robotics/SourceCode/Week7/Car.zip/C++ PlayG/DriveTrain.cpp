//
//  DriveTrain.cpp
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#include "DriveTrain.h"

DriveTrain::DriveTrain(){
    std::cout << "DriveTrain made" << std::endl;
}

DriveTrain::~DriveTrain(){
    std::cout << "DriveTrain destroyed" << std::endl;
}

void DriveTrain::Spinwheels(float KPM){
    std::cout << "CAR MOVINGMoving at " << KPM << "/min" << std::endl;
}