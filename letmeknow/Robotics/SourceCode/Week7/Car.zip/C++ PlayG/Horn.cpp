//
//  Horn.cpp
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#include "Horn.h"

Horn::Horn(){
    std::cout << "Horn made" << std::endl;
}

Horn::~Horn(){
    std::cout << "Horn destroyed" << std::endl;
}

void Horn::Beep(std::string sound){
    std::cout << "BEEP: " << sound << std::endl;
}
