//
//  Car.cpp
//  C++ PlayG
//
//  Created by Blarry_Air on 2015-11-23.
//  Copyright (c) 2015 RRISE. All rights reserved.
//

#include "Car.h"

Car::Car(){
    Car::eng = new Engine();
    Car::horn = new Horn();
    std::cout << "Car made" << std::endl;
}

Car::~Car(){
    delete eng;
    delete horn;
    std::cout << "Car destroyed" << std::endl;
}
void Car::Drive(float fast){
    eng->Rev(int(fast));
}

void Car::Honk(std::string noise){
    horn->Beep(noise);
}