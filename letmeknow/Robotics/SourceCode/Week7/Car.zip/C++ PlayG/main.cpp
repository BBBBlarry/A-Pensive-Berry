#include <iostream>
#include "CarPack.h"

#define st(x) do { x } while (__LINE__ == -1)


#define getLine() std::cout<<__LINE__<<std::endl;

int main(){
    Car* tesla = new Car();
    tesla->Drive(100);
    tesla->Drive(10);
    delete tesla;
}