#ifndef _CROBOT_HG_
#define _CROBOT_HG_

class CRobot
{
public:
  CRobot(); //constructor
  ~CRobot(); //destructor
  void KillAllHumans(void); //method
  void ShootGun(void);
};

#endif
