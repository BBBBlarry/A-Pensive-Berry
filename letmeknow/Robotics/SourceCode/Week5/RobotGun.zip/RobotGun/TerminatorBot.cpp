#include <iostream>
#include "CRobot.h"


int main()
{

  //stack base way:
  CRobot myRobot;
  myRobot.ShootGun();
    
  //heap base way:
  CRobot* pRobot = new CRobot(); // you can add parameter to your constructor
  pRobot -> ShootGun();
  //the destructor must be called, otherwise it's a memeory leak
  delete pRobot; //destructor

  return 0;
}

