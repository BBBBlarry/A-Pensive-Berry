#include "CRobot.h"
#include <iostream>

CRobot::CRobot(){
  std::cout << "I live!" << std::endl;
}
CRobot::~CRobot(){
  std::cout << "I'll be back!" << std::endl;
}


void CRobot::ShootGun(void){
  std::cout << "BANG!" << std::endl;
}



void CRobot::KillAllHumans(void){
  std::cout << "AH!" << std::endl;
}

